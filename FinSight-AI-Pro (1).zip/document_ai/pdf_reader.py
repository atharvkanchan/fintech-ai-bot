
from langchain.document_loaders import PyPDFLoader

def read_pdf(path):
    loader = PyPDFLoader(path)
    docs = loader.load()
    return docs
