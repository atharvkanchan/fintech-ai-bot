
from fastapi import APIRouter
from models.expense_model import create_expense, get_expenses

router = APIRouter()

@router.post("/add-expense")
def add_expense(data: dict):
    create_expense(data["user_id"], data["amount"], data["category"], data.get("note",""))
    return {"message":"Expense added"}

@router.get("/get-expenses/{user_id}")
def fetch(user_id: str):
    return get_expenses(user_id)
