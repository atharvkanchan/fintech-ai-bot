
from pymongo import MongoClient
from datetime import datetime

client = MongoClient("mongodb://localhost:27017/")
db = client["finsight_pro"]
col = db["expenses"]

def create_expense(user_id, amount, category, note):
    col.insert_one({
        "user_id":user_id,
        "amount":amount,
        "category":category,
        "note":note,
        "date":datetime.now()
    })

def get_expenses(user_id):
    return list(col.find({"user_id":user_id},{"_id":0}))
