
import pandas as pd

def analyze(data):
    df = pd.DataFrame(data)
    if df.empty: return {}
    df["date"]=pd.to_datetime(df["date"])
    return {
        "category":df.groupby("category")["amount"].sum().to_dict(),
        "daily":df.groupby(df["date"].dt.date)["amount"].sum().to_dict()
    }
