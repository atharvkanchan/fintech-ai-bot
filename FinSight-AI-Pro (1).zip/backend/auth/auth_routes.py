
from fastapi import APIRouter

router = APIRouter()

users = {}

@router.post("/signup")
def signup(data: dict):
    users[data["username"]] = data["password"]
    return {"message":"User created"}

@router.post("/login")
def login(data: dict):
    if users.get(data["username"]) == data["password"]:
        return {"message":"Login success"}
    return {"message":"Invalid credentials"}
