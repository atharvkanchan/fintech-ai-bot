
import streamlit as st, requests, pandas as pd

st.title("FinSight AI Pro")

user="atharv"

amount=st.number_input("Amount")
cat=st.selectbox("Category",["Food","Travel","Bills"])
note=st.text_input("Note")

if st.button("Add"):
    requests.post("http://localhost:8000/add-expense",json={
        "user_id":user,"amount":amount,"category":cat,"note":note
    })

if st.button("Load"):
    res=requests.get(f"http://localhost:8000/get-expenses/{user}")
    data=res.json()
    if data:
        df=pd.DataFrame(data)
        st.dataframe(df)
        st.bar_chart(df.groupby("category")["amount"].sum())
